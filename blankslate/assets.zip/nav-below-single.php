<div class="entry-content" itemprop="mainEntityOfPage">

<?php the_content(); ?>
<div class="entry-links">
	<a href="/#news" class="btn btn--purple btn--animated action__cta read-more">More News and Announcements</a>
</div>
</div>